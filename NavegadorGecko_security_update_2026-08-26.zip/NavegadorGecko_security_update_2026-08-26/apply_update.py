#!/usr/bin/env python3
"""One-time, idempotent hardening update for NavegadorGecko v0.13.5 -> v0.13.6.

This is a source updater, not a build-time source mutator. The resulting source
must be committed before release artifacts are built.
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

JAVA_DIR = Path("app/src/main/java/com/ejemplo/navegador")


def read(path: Path) -> str:
    if not path.is_file():
        raise RuntimeError(f"Falta archivo requerido: {path}")
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def replace_once(path: Path, old: str, new: str, label: str) -> bool:
    text = read(path)
    if new in text:
        print(f"  = {label}: ya aplicado")
        return False
    if old not in text:
        raise RuntimeError(f"No se encontró el bloque esperado para: {label} ({path})")
    write(path, text.replace(old, new, 1))
    print(f"  ✓ {label}")
    return True


def copy_payload(script_dir: Path, repo: Path) -> None:
    payload = script_dir / "payload"
    if not payload.is_dir():
        raise RuntimeError("El ZIP no contiene payload/")
    for source in payload.rglob("*"):
        if not source.is_file():
            continue
        rel = source.relative_to(payload)
        destination = repo / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        print(f"  ✓ reemplazado {rel.as_posix()}")


def patch_version(repo: Path) -> None:
    path = repo / "app/build.gradle.kts"
    text = read(path)
    if 'versionCode = 23' in text and 'versionName = "0.13.6"' in text:
        print("  = versión 0.13.6: ya aplicada")
        return
    if 'versionCode = 22' not in text or 'versionName = "0.13.5"' not in text:
        raise RuntimeError("Versión base inesperada; se esperaba 0.13.5 / versionCode 22")
    text = text.replace('versionCode = 22', 'versionCode = 23', 1)
    text = text.replace('versionName = "0.13.5"', 'versionName = "0.13.6"', 1)
    write(path, text)
    print("  ✓ versión 0.13.6 / versionCode 23")


def patch_extension_manager(repo: Path) -> None:
    path = repo / JAVA_DIR / "ExtensionManager.kt"

    old = '''        return path.endsWith(".xpi") ||
            (host.endsWith("addons.mozilla.org") && path.contains("/downloads/"))'''
    new = '''        val trustedAmoHost =
            host == "addons.mozilla.org" ||
                host.endsWith(".addons.mozilla.org")

        // No auto-instalar XPI desde hosts arbitrarios. GeckoView valida
        // la firma, pero el origen también debe ser el AMO oficial.
        return trustedAmoHost &&
            (path.endsWith(".xpi") || path.contains("/downloads/"))'''
    replace_once(path, old, new, "allowlist estricta para Mozilla Add-ons")

    old = '''            val manifest =
                zip.getEntry(
                    "manifest.json"
                )
                    ?: error(
                        "No existe manifest.json en la raíz."
                    )'''
    new = '''            var entries = 0
            var expandedBytes = 0L
            val allEntries = zip.entries()

            while (allEntries.hasMoreElements()) {
                val entry = allEntries.nextElement()
                entries += 1

                if (entries > 4000) {
                    error("La extensión contiene demasiadas entradas.")
                }

                val normalized = entry.name.replace('\\\\', '/')
                val segments = normalized.split('/')

                if (
                    normalized.startsWith('/') ||
                    normalized.startsWith("\\\\") ||
                    segments.any { it == ".." } ||
                    normalized.indexOf('\\u0000') >= 0
                ) {
                    error("Ruta insegura dentro del paquete: ${entry.name}")
                }

                if (entry.size > 0L) {
                    expandedBytes += entry.size
                    if (expandedBytes > 250L * 1024L * 1024L) {
                        error("El contenido expandido del XPI supera 250 MB.")
                    }
                }
            }

            val manifest =
                zip.getEntry(
                    "manifest.json"
                )
                    ?: error(
                        "No existe manifest.json en la raíz."
                    )'''
    replace_once(path, old, new, "validación defensiva de rutas/zip-bomb en XPI")

    old = '''                if (nativeApp != NATIVE_APP) return null

                val context = AppContext.get()
                val tab = sender.session?.let { TabManager.tabForSession(it) }

                return GeckoResult.fromValue(
                    JSONObject().apply {
                        put("ok", true)
                        put("showBadge", false)
                        put("backgroundMedia", BrowserPrefs.backgroundMedia(context))
                        put("smartPip", BrowserPrefs.smartPip(context))
                        put("theme", BrowserPrefs.theme(context))
                        put("accent", BrowserPrefs.accent(context))
                        put("tabId", tab?.id ?: "")
                        put("private", tab?.isPrivate ?: false)
                        put("url", tab?.url ?: "")
                    }
                )'''
    new = '''                if (
                    nativeApp != NATIVE_APP ||
                    !sender.isTopLevel() ||
                    sender.session == null
                ) {
                    return null
                }

                val context = AppContext.get()

                // Superficie mínima: el bridge solo necesita estado de
                // reproducción/PiP. No exponer URL, id de pestaña ni modo privado.
                return GeckoResult.fromValue(
                    JSONObject().apply {
                        put("ok", true)
                        put("backgroundMedia", BrowserPrefs.backgroundMedia(context))
                        put("smartPip", BrowserPrefs.smartPip(context))
                    }
                )'''
    replace_once(path, old, new, "bridge nativo con respuesta mínima y solo top-level")

    old = '''            override fun onConnect(port: WebExtension.Port) {
                ports += port

                port.setDelegate('''
    new = '''            override fun onConnect(port: WebExtension.Port) {
                if (
                    !port.sender.isTopLevel() ||
                    port.sender.session == null
                ) {
                    runCatching { port.disconnect() }
                    return
                }

                ports += port

                port.setDelegate('''
    replace_once(path, old, new, "rechazar puertos bridge de frames/no-session")

    old = '''                            port.postMessage(
                                JSONObject().apply {
                                    put("type", "native_ack")
                                    put("received", message.toString())
                                    put("showBadge", false)
                                    put("backgroundMedia", BrowserPrefs.backgroundMedia(AppContext.get()))
                                }
                            )'''
    new = '''                            // Los mensajes no reconocidos no se reflejan de vuelta
                            // al contenido. Esto evita convertir el bridge en un eco de datos.
                            return'''
    replace_once(path, old, new, "eliminar eco de mensajes arbitrarios del bridge")


def patch_tab_manager(repo: Path) -> None:
    path = repo / JAVA_DIR / "TabManager.kt"

    anchor = '''    private fun normalizeMobileUrl(
        url: String,
        desktopMode: Boolean
    ): String {'''
    helper = '''    private fun isSafeAppNavigationUrl(url: String): Boolean {
        val uri = runCatching { Uri.parse(url.trim()) }.getOrNull() ?: return false
        return when (uri.scheme?.lowercase()) {
            "http", "https", "about", "resource", "moz-extension" -> true
            else -> false
        }
    }

    private fun normalizeMobileUrl(
        url: String,
        desktopMode: Boolean
    ): String {'''
    replace_once(path, anchor, helper, "allowlist de esquemas para navegación iniciada por la app")

    old = '''        val tab = BrowserTab(
            url = url,
            title = if (isPrivate) "Pestaña privada" else "Nueva pestaña",
            isPrivate = isPrivate
        )'''
    new = '''        val initialUrl =
            if (isSafeAppNavigationUrl(url)) {
                url
            } else {
                listener?.onMessage("Nexo bloqueó un esquema de URL no permitido.")
                BrowserPrefs.homePage(requireContext())
            }

        val tab = BrowserTab(
            url = initialUrl,
            title = if (isPrivate) "Pestaña privada" else "Nueva pestaña",
            isPrivate = isPrivate
        )'''
    replace_once(path, old, new, "filtrar URL al crear pestañas desde la app")

    old = '''    fun navigate(url: String) {
        val tab = activeTab() ?: return
        val target =
            normalizeMobileUrl(
                url,
                tab.desktopMode
            )'''
    new = '''    fun navigate(url: String) {
        val tab = activeTab() ?: return

        if (!isSafeAppNavigationUrl(url)) {
            listener?.onMessage("Nexo bloqueó un esquema de URL no permitido.")
            return
        }

        val target =
            normalizeMobileUrl(
                url,
                tab.desktopMode
            )'''
    replace_once(path, old, new, "bloquear javascript/file/data/content/intent en navegación de la app")

    old = '''                            url = o.optString(
                                "url",
                                BrowserPrefs.homePage(context)
                            ).let { restoredUrl ->
                                if (restoredUrl.startsWith("resource://android/assets/home/")) {
                                    BrowserPrefs.homePage(context)
                                } else restoredUrl
                            },'''
    new = '''                            url = o.optString(
                                "url",
                                BrowserPrefs.homePage(context)
                            ).let { restoredUrl ->
                                val candidate =
                                    if (restoredUrl.startsWith("resource://android/assets/home/")) {
                                        BrowserPrefs.homePage(context)
                                    } else {
                                        restoredUrl
                                    }

                                if (isSafeAppNavigationUrl(candidate)) {
                                    candidate
                                } else {
                                    BrowserPrefs.homePage(context)
                                }
                            },'''
    replace_once(path, old, new, "sanitizar URLs restauradas desde preferencias")


def patch_main_activity(repo: Path) -> None:
    path = repo / JAVA_DIR / "MainActivity.kt"

    old = '''            val uri = Uri.parse(url)
            val name = uri.lastPathSegment?.substringAfterLast('/')
                ?.takeIf { it.isNotBlank() } ?: "nexo_${System.currentTimeMillis()}"
            val request = DownloadManager.Request(uri)'''
    new = '''            val uri = Uri.parse(url)
            val rawName = uri.lastPathSegment
                ?.substringAfterLast('/')
                ?.takeIf { it.isNotBlank() }
                ?: "nexo_${System.currentTimeMillis()}"
            val name = rawName
                .replace(Regex("""[\\\\/:*?"<>|\\p{Cntrl}]"""), "_")
                .replace("..", "_")
                .trim()
                .trimStart('.')
                .take(120)
                .ifBlank { "nexo_${System.currentTimeMillis()}" }
            val request = DownloadManager.Request(uri)'''
    replace_once(path, old, new, "sanitizar nombre para DownloadManager")

    old = '''    private fun handleNavigationIntent(intent: Intent?) {
        intent?.getStringExtra(EXTRA_OPEN_URL)?.takeIf { it.isNotBlank() }?.let {
            TabManager.navigate(it)
        }
    }'''
    new = '''    private fun handleNavigationIntent(intent: Intent?) {
        val raw = intent
            ?.getStringExtra(EXTRA_OPEN_URL)
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: return

        val scheme = runCatching { Uri.parse(raw).scheme?.lowercase() }
            .getOrNull()

        if (
            scheme !in setOf(
                "http",
                "https",
                "about",
                "resource",
                "moz-extension"
            )
        ) {
            Toast.makeText(
                this,
                "Nexo bloqueó un enlace con esquema no permitido",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        TabManager.navigate(raw)
    }'''
    replace_once(path, old, new, "validar esquemas de intents entrantes")


def verify(repo: Path) -> None:
    ext = read(repo / JAVA_DIR / "ExtensionManager.kt")
    tabs = read(repo / JAVA_DIR / "TabManager.kt")
    app = read(repo / JAVA_DIR / "NexoApplication.kt")
    dl = read(repo / JAVA_DIR / "DownloadStore.kt")
    gradle = read(repo / "app/build.gradle.kts")
    workflow = read(repo / ".github/workflows/main.yml")

    checks = {
        "versión 0.13.6": 'versionName = "0.13.6"' in gradle,
        "AMO estricto": 'host == "addons.mozilla.org"' in ext and 'host.endsWith(".addons.mozilla.org")' in ext,
        "bridge top-level": '!sender.isTopLevel()' in ext,
        "sin bridge URL": 'put("url", tab?.url' not in ext,
        "navegación segura": 'isSafeAppNavigationUrl' in tabs,
        "crash redaction": 'redactCrashReport' in app,
        "descarga canonical": 'canonicalFile' in dl,
        "workflow nuevo instalado": 'Nexo Secure CI, Update and Release' in workflow,
        "CI con permisos mínimos": 'contents: read' in workflow,
        "workflow antiguo retirado": workflow.startswith("name: Nexo Secure CI, Update and Release"),
    }
    failed = [name for name, ok in checks.items() if not ok]
    if failed:
        raise RuntimeError("Fallaron verificaciones: " + ", ".join(failed))
    print("  ✓ verificaciones estáticas del update")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=".", help="Raíz del repositorio NavegadorGecko")
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    script_dir = Path(__file__).resolve().parent

    if not (repo / "settings.gradle.kts").is_file() or not (repo / "app").is_dir():
        raise RuntimeError(f"No parece ser NavegadorGecko: {repo}")

    print("[1/7] Copiando archivos endurecidos")
    copy_payload(script_dir, repo)
    print("[2/7] Actualizando versión")
    patch_version(repo)
    print("[3/7] Endureciendo ExtensionManager")
    patch_extension_manager(repo)
    print("[4/7] Endureciendo TabManager")
    patch_tab_manager(repo)
    print("[5/7] Endureciendo MainActivity")
    patch_main_activity(repo)
    print("[6/7] Verificando")
    verify(repo)
    print("[7/7] Update aplicado. Compila y revisa el diff antes de liberar.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
