# NavegadorGecko — Security Update v0.13.6

Base revisada: `main` / tree `d4b5c3ea204c9f91e43c9196487f7c55dba94dd3` (26-08-2026).

## Qué corrige este update

- Sustituye el workflow de ~40 KB que reescribía Kotlin/JS/XML durante el build por CI de solo lectura: el APK se compila exactamente desde código ya versionado.
- El nuevo `.github/workflows/main.yml` separa CI, aplicación del update y release en jobs distintos, y exige una clave Android persistente para publicar.
- Corrige la validación AMO para aceptar únicamente `addons.mozilla.org` o subdominios reales de ese dominio; deja de auto-instalar `.xpi` desde hosts HTTPS arbitrarios.
- Añade validación defensiva de entradas ZIP/XPI: rutas `..`, rutas absolutas, cantidad de entradas y tamaño expandido.
- Reduce el bridge nativo a sesiones top-level y elimina exposición de URL/id/modo privado y el eco de mensajes arbitrarios.
- Bloquea navegación iniciada por la app con `javascript:`, `file:`, `data:`, `content:` e `intent:`.
- Sanitiza nombres de descarga y valida canónicamente que los archivos gestionados permanezcan dentro de la carpeta de descargas.
- Impide que una ruta almacenada fuera de la carpeta administrada sea eliminada por `DownloadStore.remove()`.
- Redacta tokens, query strings y rutas internas de los crash logs antes de mostrarlos o copiarlos.
- Activa StrictMode en builds debuggable.
- Maneja de forma segura errores de `FileProvider`, mantiene sus rutas limitadas a carpetas concretas y añade estado vacío básico a Descargas.
- Amplía `.gitignore` para APK/AAB, keystores, claves, secrets y logs.
- Actualiza a `versionCode 23`, `versionName 0.13.6`.

## Hallazgos del informe que no corresponden al `main` actual

La auditoría recibida mezcla problemas de una versión anterior con el código actual. En `main` ya no existe `useMultiprocess(false)` ni `aboutConfigEnabled(true)`; `TabManager` ya usa `CopyOnWriteArrayList`; los `PendingIntent` ya usan `FLAG_IMMUTABLE`; R8/minify ya está activo; `SearchResolver` ya codifica consultas; el traductor usa ML Kit en el dispositivo; no existe `addJavascriptInterface`; `ThemeManager` no inyecta CSS de usuario en páginas; y `ExtensionManager` no descomprime XPI al filesystem.

Por eso este paquete no añade APIs o dependencias innecesarias para “corregir” hallazgos que ya no existen.

## Certificate pinning

No se añade pinning estático para AMO. Un pin mal mantenido puede dejar inservible la tienda cuando Mozilla/CDN rote certificados. La defensa aplicada es TLS del sistema + host allowlist estricta + verificación de firma de extensiones por GeckoView. Si en el futuro se implementa pinning, debe existir una estrategia real de backup pins y rotación.

## Clave de firma: requisito crítico

El workflow anterior generaba un keystore nuevo en cada ejecución. Android solo permite actualizar una app si el nuevo APK está firmado con la misma identidad criptográfica que el APK instalado.

Desde v0.13.6 se exige configurar estos GitHub Secrets:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Si la clave con la que se firmó un APK 0.13.5 ya instalado no fue guardada, **no existe una solución técnica para firmar 0.13.6 como la misma app**. Ese dispositivo tendrá que desinstalar la versión anterior e instalar una vez la nueva versión; a partir de ahí, conserva y reutiliza la nueva clave para todas las releases futuras.

## Uso

1. Sube `NavegadorGecko_security_update_2026-08-26.zip` a la raíz del repositorio.
2. **Reemplaza** el workflow actual por el `main.yml` entregado en `.github/workflows/main.yml`. No dejes el workflow viejo de 40 KB activo.
3. En GitHub Actions ejecuta **Nexo Secure CI, Update and Release** con `mode=apply_update`.
4. El job valida el ZIP, aplica el update, compila/lint y solo entonces hace commit del código resultante a `main`.
5. Para una compilación normal usa `mode=build`. Para publicar, configura los secrets de firma y usa `mode=release`.

El permiso `contents: write` se concede únicamente a los jobs manuales que realmente escriben (`apply-update` y `release`); el CI normal conserva `contents: read`. El workflow no intenta editar sus propios archivos desde `GITHUB_TOKEN`.
